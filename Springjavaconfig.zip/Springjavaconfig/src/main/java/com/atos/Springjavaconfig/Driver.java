package com.atos.Springjavaconfig;

public class Driver {

	public Driver() {
		System.out.println("driver created");
		}
}
