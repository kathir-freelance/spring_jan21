package com.atos.Springjavaconfig;

public class Vehicle {

	private Engine eng;
	public Engine getEng() {
		return eng;
	}
	public void setEng(Engine eng) {
		this.eng = eng;
	}
	public Vehicle() {
	System.out.println("vehicle created");
	}
	public Vehicle(Engine eng) {
		super();
		this.eng = eng;
	}
	
}
