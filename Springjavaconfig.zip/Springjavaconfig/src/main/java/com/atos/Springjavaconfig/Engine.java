package com.atos.Springjavaconfig;

import org.springframework.stereotype.Component;

@Component
public class Engine {
public Engine() {
	System.out.println("engine obj created");
}



}
