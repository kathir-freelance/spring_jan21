package com.atos.Springjavaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	
	@Bean
	public Vehicle getVehicle() {
		 Vehicle v=new Vehicle();
		 v.setEng(getEngine());
		 return v;
	}
	@Bean(value = "driverObj")
	public Driver getDriver() {
		return new Driver();
	}
	@Bean
	public Engine getEngine() {
		return new Engine();
	}
}
