package com.atos.Springjavaconfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		/*
		 * ApplicationContext ctx=new
		 * AnnotationConfigApplicationContext(AppConfig.class);
		 * 
		 * Vehicle v1=(Vehicle)ctx.getBean("getVehicle"); System.out.println(v1);
		 * System.out.println(v1.getEng()); Driver d1=(Driver)ctx.getBean("driverObj");
		 * System.out.println(d1);
		 */  
    	AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(AppConfig.class);
    	ctx.register(Data.class);
    	//ctx.refresh();
    	Vehicle v1=(Vehicle)ctx.getBean("getVehicle");
    	System.out.println(v1);
    	System.out.println(v1.getEng());
    	Driver d1=(Driver)ctx.getBean("driverObj");
    	System.out.println(d1);
	
    	
    }
}
