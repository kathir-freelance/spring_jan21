package com.atos.Springjavaconfig;

public class Data {

	public Data() {
	System.out.println("data created");
	}
}
