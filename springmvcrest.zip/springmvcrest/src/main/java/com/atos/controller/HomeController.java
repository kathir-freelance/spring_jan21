package com.atos.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;
@RestController //@Contoller + @ResponseBody
public class HomeController {
	
	ArrayList<Employee> empList=null;
	public HomeController() {
		empList=new ArrayList<Employee>();
		empList.add(new Employee(124,"jay","Hyderabad"));
		empList.add(new Employee(125,"jagan","Chennai"));
		empList.add(new Employee(126,"vinay","Mumbai"));
	}
	@RequestMapping("/stringData")
	public String getStringData() {
	
		return "welcome to rest services";
		
	}
	
	@RequestMapping("/htmlData")
	public String getHtmlData() {	
		return "<h1>welcome to rest services</h1>";
		
	}
	@RequestMapping("/empObj")
	public Employee getEmployeeObj() {
	
		return new Employee(123,"ajay","Pune") ;
		
	}
	@RequestMapping("/allempObj")
	public ArrayList<Employee> getAllEmployeeObj() {
	
		return empList;
		
	}
	//front end application ----json format ---consume json and convert it inot java obj (arraylist or normal class)
	@RequestMapping(value="/store",method=RequestMethod.POST)
	public String storeEmpl(@RequestBody Employee emp) {
		System.out.println(emp);
		empList.add(emp);		
		return "successfully stored";
	}

}
