package com.atos.SpringbootDemo1;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HomeController {

	ArrayList<Employee> empList=null;
	public HomeController() {
		empList=new ArrayList<Employee>();
		empList.add(new Employee(124,"jay","Hyderabad"));
		empList.add(new Employee(125,"jagan","Chennai"));
		empList.add(new Employee(126,"vinay","Mumbai"));
	}
	
	@RequestMapping("stringData")
	public String getStringData() {
		return "hi hello...";
	}
	@RequestMapping("htmlData")
	public String getHtmlData() {
		return "<h1>hi hello</h1>";
	}
	@RequestMapping("/empObj")
	public Employee getEmployeeObj() {
	
		return new Employee(123,"ajay","Pune") ;
		
	}
	//@Request
	@GetMapping("/allempObj")
	public ArrayList<Employee> getAllEmployeeObj() {
	
		return empList;
		
	}
	@GetMapping("/movie")
	public String getMovieDetailsById(@RequestParam("id") int id) {
	System.out.println("in movie details by id");
		return "movie id is "+id;
		
	}
	@GetMapping("/movie/{name}")
	public String getMovieDetailsByName(@PathVariable("name") String mName) {
	
		return "movie name is "+mName;
		
	}
	//@RequestMapping(value="/store",method=RequestMethod.POST)
	@PostMapping("/store")
	public String storeEmpl(@RequestBody Employee emp) {
		System.out.println(emp);
		empList.add(emp);		
		return "successfully stored";
	}

}
