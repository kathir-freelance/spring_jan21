package com.atos.myapp2_annotations;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component(value = "carObj")
@Scope(value = "prototype")
public class Car {
	
	//@Value("[1,2,3,4]")
	//private int a[];

	@Value(value = "1234")
	private int regNum;
	@Value("Audi")
	private String name;
	
	public String getName() {
		return name;
	}
	public int getRegNum() {
		return regNum;
	}
	public void setRegNum(int regNum) {
		this.regNum = regNum;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Car() {
		System.out.println("car obj created");
	}
	@Override
	public String toString() {
		return "Car [regNum=" + regNum + ", name=" + name + "]";
	}
	
	
}
