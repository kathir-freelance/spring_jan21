package com.atos.myapp5_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		
		  ApplicationContext ctx=new ClassPathXmlApplicationContext("springs.xml"); 
		  EmployeeDao e=(EmployeeDao)ctx.getBean("eDao");
		  System.out.println(e);
		  
		  JdbcTemplate myJdbc= e.getJdbc();
	//	  String qry="select * from employee ";
	//	  String qry="select * from employee where salary<? and name=? ";
	//	List<Employee> empList=  myJdbc.query(qry,new Object[] {6,"tata"},new EmployeeRowMapper());
	//	System.out.println(empList);
	//	  String qry="select name from employee where salary<6"; 
	//	  List<String> empNames=myJdbc.queryForList(qry, String.class);
	//	 System.out.println(empNames);
		  
		  String qry="insert into employee values(?,?,?)";
		 int status= myJdbc.update(qry,new Object[] {1119,"hyn",7});
		 System.out.println(status+" inserted");
    }
}

class EmployeeRowMapper implements RowMapper<Employee>{

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employee e=new Employee(rs.getInt(1),rs.getString(2),rs.getFloat(3));
		return e;
	}
	
	
}
