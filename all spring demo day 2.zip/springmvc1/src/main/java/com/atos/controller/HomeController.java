package com.atos.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller//(sub annotation of @component)
public class HomeController {

	private List<String> movieList=null;
	
		public HomeController() {
			movieList=new ArrayList<String>();
			movieList.add("IronMan");
			movieList.add("Hulk");
			movieList.add("Black Panther");
		}
		
		@ModelAttribute("mList")
		public List<String> init() {			
			movieList=new ArrayList<String>();
			movieList.add("IronMan1");
			movieList.add("Hulk2");
			movieList.add("Black Panther2");
			return movieList;
		}
	/*
	 * @RequestMapping(value={"home","home.aspx","home.php","home/*"}) public String
	 * getHome() { return "homepage"; }
	 */
	
	/*
	 * @RequestMapping(value={"home","home.aspx","home.php","home/*"}) public String
	 * getHome(Model m) { String msg="welcome to my home page";
	 * m.addAttribute("mydata", msg); return "homepage"; }
	 */
	
	@RequestMapping(value={"home","home.aspx","home.php","home/*"})
	public ModelAndView getHome() {
		ModelAndView mv=new ModelAndView("homepage");
		String msg="welcome to my home page";
		mv.addObject("mydata", msg);
		mv.addObject("movies",movieList);
		return mv;
	}
	
	@RequestMapping(value="product")
	public String getProduct(@RequestParam("name") String name,@RequestParam("price") float price ,Model m) {
		m.addAttribute("n",name);
		m.addAttribute("p",price);
		
		return "product";
	}
	
	
	
	
@RequestMapping(value="store",method =RequestMethod.POST)
	public String storeData(@RequestParam("un") String n,@RequestParam("city") String city,Model m) {
		m.addAttribute("n",n);
		m.addAttribute("c",city);
		
		return "emp";
	}
	
	@RequestMapping("movie/{name}")
	public String getPathParam(@PathVariable("name") String path ) {
		System.out.println(path);
		return "";
	}

	
}
