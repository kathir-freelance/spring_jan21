package com.atos.myapp2_annotations;

import org.springframework.stereotype.Component;

@Component
public class Engine {
public Engine() {
	System.out.println("engine obj created");
}



}
