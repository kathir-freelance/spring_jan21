package com.atos.myapp2_annotations;

import org.springframework.stereotype.Component;

@Component
public class A {

	public A() {
		System.out.println("A class Object");
	}
}
