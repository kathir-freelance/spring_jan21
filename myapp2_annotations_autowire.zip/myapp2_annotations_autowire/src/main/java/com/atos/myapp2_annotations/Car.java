package com.atos.myapp2_annotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component(value = "carObj")
@Scope(value = "prototype")
public class Car {
	
	//@Value("[1,2,3,4]")
	//private int a[];

	@Value(value = "1234")
	private int regNum;
	@Value("Audi")
	private String name;
	
	@Autowired(required = false)
	private Engine engine;


	public int getRegNum() {
		return regNum;
	}


	public void setRegNum(int regNum) {
		this.regNum = regNum;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Engine getEngine() {
		return engine;
	}


	public void setEngine(Engine engine) {
		this.engine = engine;
	}


	public Car(int regNum, String name, Engine engine) {
		super();
		this.regNum = regNum;
		this.name = name;
		this.engine = engine;
	}
	public Car() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "Car [regNum=" + regNum + ", name=" + name + ", engine=" + engine + "]";
	}
	
	
}
