package com.atos.myapp2_annotations;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		
		  ApplicationContext ctx=new ClassPathXmlApplicationContext("springs.xml"); 
		 // Car c1=(Car)ctx.getBean("car");//takes the class name (lower case)
		  Car c1=(Car)ctx.getBean("carObj");
		  
		 System.out.println(c1);
		 System.out.println(c1.getEngine());
		 
	   }
}
