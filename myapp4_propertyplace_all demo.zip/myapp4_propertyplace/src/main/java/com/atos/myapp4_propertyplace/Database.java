package com.atos.myapp4_propertyplace;

public class Database {

	private String driver;
	private String name;
	private String pwd;
	public String getDriver() {
		return driver;
	}
	public void setDriver(String driver) {
		this.driver = driver;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	@Override
	public String toString() {
		return "Database [driver=" + driver + ", name=" + name + ", pwd=" + pwd + "]";
	}
	
	
	}
