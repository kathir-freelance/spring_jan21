package com.atos.myapp4_propertyplace;

public class Engine {
public Engine() {
	System.out.println("engine obj created");
}
}
