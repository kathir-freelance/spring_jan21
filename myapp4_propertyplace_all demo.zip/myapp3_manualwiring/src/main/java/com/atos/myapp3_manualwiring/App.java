package com.atos.myapp3_manualwiring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		
		/*
		 * BeanFactory bf=null; Resource res=new ClassPathResource("springs.xml");
		 * bf=new XmlBeanFactory(res); Car c=(Car)bf.getBean("car1");
		 * System.out.println(c); Car c1=(Car)bf.getBean("car1");
		 * System.out.println(c1);
		 * 
		 */
		
		  ApplicationContext ctx=new ClassPathXmlApplicationContext("springs.xml"); 
		  Car c1=(Car)ctx.getBean("car2");
		 System.out.println(c1);
		 System.out.println(c1.getEng());
		 
    }
}
