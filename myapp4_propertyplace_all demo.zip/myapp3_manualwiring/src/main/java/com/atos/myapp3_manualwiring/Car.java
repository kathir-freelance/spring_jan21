package com.atos.myapp3_manualwiring;

public class Car {

	private int regNum;
	private String name;
	
	private Engine eng;
	
	public void setEng(Engine eng) {
		this.eng = eng;
	}
	public Engine getEng() {
		return eng;
	}
	
	public String getName() {
		return name;
	}
	public int getRegNum() {
		return regNum;
	}
	public void setRegNum(int regNum) {
		this.regNum = regNum;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Car() {
		System.out.println("car obj created");
	}
	@Override
	public String toString() {
		return "Car [regNum=" + regNum + ", name=" + name + "]";
	}
	
	
}
