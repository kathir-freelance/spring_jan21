package com.atos.myapp3_manualwiring;

public class Engine {
public Engine() {
	System.out.println("engine obj created");
}
}
