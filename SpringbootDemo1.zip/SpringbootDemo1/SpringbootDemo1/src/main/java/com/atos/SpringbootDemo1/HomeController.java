package com.atos.SpringbootDemo1;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HomeController {

	ArrayList<Employee> empList=null;
	public HomeController() {
		empList=new ArrayList<Employee>();
		empList.add(new Employee(124,"jay","Hyderabad"));
		empList.add(new Employee(125,"jagan","Chennai"));
		empList.add(new Employee(126,"vinay","Mumbai"));
	}
	
	@RequestMapping("stringData")
	public String getStringData() {
		return "hi hello...";
	}
	@RequestMapping("htmlData")
	public String getHtmlData() {
		return "<h1>hi hello</h1>";
	}
	@RequestMapping("/empObj")
	public Employee getEmployeeObj() {
	
		return new Employee(123,"ajay","Pune") ;
		
	}
	@RequestMapping("/allempObj")
	public ArrayList<Employee> getAllEmployeeObj() {
	
		return empList;
		
	}
	@RequestMapping(value="/store",method=RequestMethod.POST)
	public String storeEmpl(@RequestBody Employee emp) {
		System.out.println(emp);
		empList.add(emp);		
		return "successfully stored";
	}

}
