package com.atos.myapp1;

public class Car {

	public Car() {
		System.out.println("car obj created");
	}
}
