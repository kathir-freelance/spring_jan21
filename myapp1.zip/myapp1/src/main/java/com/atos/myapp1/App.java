package com.atos.myapp1;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        BeanFactory bf=null;
        Resource res=new ClassPathResource("springs.xml");
        bf=new XmlBeanFactory(res);
        Car c=(Car)bf.getBean("car1");
        System.out.println(c);
        
    }
}
